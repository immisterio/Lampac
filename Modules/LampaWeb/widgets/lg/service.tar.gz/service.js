process.on('uncaughtException', function (err) {
    
});

var tiks = 0;

var Arrays = new function(){
    this.remove = function(a,b){
        var inx = a.indexOf( b );
        
        if(inx >= 0) a.splice( inx, 1 );
    }
}

var Console = {
    logs: [],
    log: function(msg, isjson){
        Console.logs.push(isjson ? JSON.stringify(msg, null, "\t") : msg)
    },
    get: function(){
        return Console.logs.join("\n\n----\n\n");
    },
    all: function(){
        return Console.logs;
    },
    clear: function(){
        Console.logs = [];
    }
}

var Api = function(){
    var parser  = require('xml-js');
    var request = require('request');
    var ssdp    = require('node-ssdp').Client;
    var upnp    = new ssdp({explicitSocketBind: true, reuseAddr: true});

    var locations = [], find = [];
    
    
    this.devices = function(){
        return getDevice();
    }

    this.search = function(){
        scanNow();
    }
    
    
    this.send = function(data, object, callback){
        Console.clear();

        var name  = object.name.toLowerCase();
        var xml   = "<?xml version=\"1.0\" encoding=\"utf-8\"?><s:Envelope s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body><u:SetAVTransportURI xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"><InstanceID>0</InstanceID><CurrentURI>${1}</CurrentURI><CurrentURIMetaData>&lt;DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dlna=\"urn:schemas-dlna-org:metadata-1-0/\" xmlns:sec=\"http://www.sec.co.kr/\"&gt;&lt;item id=\"${uid}\" parentID=\"parent\" restricted=\"1\"&gt;&lt;upnp:class&gt;object.item.videoItem&lt;/upnp:class&gt;&lt;dc:title&gt;${name}&lt;/dc:title&gt;&lt;dc:creator&gt;Lampa&lt;/dc:creator&gt;&lt;upnp:artist&gt;Lampa&lt;/upnp:artist&gt;&lt;upnp:album&gt;Lampa&lt;/upnp:album&gt;&lt;res protocolInfo=\"http-get:*:${type}:DLNA.ORG_OP=01;DLNA.ORG_FLAGS=01700000000000000000000000000000\"&gt;${2}&lt;/res&gt;&lt;/item&gt;&lt;/DIDL-Lite&gt;</CurrentURIMetaData></u:SetAVTransportURI></s:Body></s:Envelope>";
        var heads = {
            'TransferMode.dlna.org': 'Streaming',
            'Contentfeatures.dlna.org': 'DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000',
        }

        xml = xml.replace(/\$\{1\}/g,  data.url)
        xml = xml.replace(/\$\{2\}/g,  data.url)
        xml = xml.replace(/\$\{type\}/g, data.type || 'video/mp4')
        xml = xml.replace(/\$\{name\}/g, data.name || 'Lampa')
        xml = xml.replace(/\$\{uid\}/g, uid())

        
        
        var ip       = object.headers.LOCATION.replace('http://','').split('/')[0];
        var soap_url = 'http://' + ip + object.transport;

        //soap_url = object.headers.LOCATION + object.transport.slice(1);

        Console.log('play url: ' + data.url);
        Console.log('soap url: ' + soap_url);

        callSoap({
            url: soap_url,
            xml: xml,
            action: 'SetAVTransportURI',
            headers: heads
        }, function(){
            setTimeout(function(){
                callSoap({
                    url: soap_url,
                    xml: "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><s:Envelope s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body><u:Play xmlns:u=\"urn:schemas-upnp-org:service:AVTransport:1\"><InstanceID>0</InstanceID><Speed>1</Speed></u:Play></s:Body></s:Envelope>",
                    action: 'Play',
                }, function(){
                    callback({className: 'white', code: 3});
                }, function(){
                    callback({className: 'error', code: 2});
                })
            }, 1000)
        }, function(){
            callback({className: 'error', code: 1});
        })
    }

    var uid = function(len){
        var ALPHABET  = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var ID_LENGTH = len || 5;

        var id = '';

        for (var i = 0; i < ID_LENGTH; i++) {
            id += ALPHABET.charAt(Math.floor(Math.random() * ALPHABET.length));
        }

        return id;
    }

    var scanNow = function(){
        locations = [];

        tiks++;

        Console.clear();

        upnp.search('ssdp:all')
    }
    
    var getDevice = function(){
        //return [{name: 'webOS', transport: '/test.html', headers: {LOCATION: 'http://troll.ru'}}]

        return find.filter(function(a){
            return a.transport ? true : false
        });
    }

    var callSoap = function(data, call_callback, call_error){
        var send = {
            url: data.url,
            method: 'POST',
            headers: {
                'Content-Type': 'text/xml; charset=utf-8',
                'SOAPAction': '"urn:schemas-upnp-org:service:AVTransport:1#' + data.action + '"',
                'Content-Length': data.xml.length
            },
            body: data.xml
        };

        if(data.headers){
            for(var i in data.headers){
                send.headers[i] = data.headers[i];
            }
        }

        request(send, function (error, response, body){
            Console.log('soap responce: ' + (response ? response.statusCode : 0));

            if(response && response.statusCode == 200) call_callback(body);
            else call_error(body);
        });
    }
    
    var checkXML = function(object){
        var send = {
            url: object.headers.LOCATION,
            method: 'GET'
        };

        request(send, function (error, response, body){
            if(response && response.statusCode == 200){
                try{
                    var json     = JSON.parse(parser.xml2json(body, {compact: true, spaces: 4}));
                    var services = json.root.device.serviceList.service;
                    
                    for (var i = 0; i < services.length; i++) {
                        var s = services[i];

                        Console.log(s.controlURL._text)

                        Console.log('define transport: ' + s.controlURL._text);

                        if(s.controlURL._text.indexOf('AVTransport') >= 0){
                            object.transport = s.controlURL._text;
                        }
                    }

                    object.name = json.root.device.friendlyName._text;
                }
                catch(e){
                    Console.log(e.message)
                }
            }
        });
    }


    upnp.on('response', function(headers, code, rinfo) {
        if(locations.indexOf(headers.LOCATION) == -1) {
            var server = (headers.SERVER || '').toLowerCase()
            
            if(server.indexOf('webos') > -1){
                var d = false;

                for (var i = 0; i < find.length; i++) {
                    if(find[i].headers.SERVER == headers.SERVER) d = find[i];
                }

                if(d) Arrays.remove(find, d);

                var object = {
                    headers: headers,
                    rinfo: rinfo,
                    name:  headers.SERVER
                }

                checkXML(object);

                find.push(object)
            }

            locations.push(headers.LOCATION);

            difing++;
        }
    })

    setInterval(scanNow, 2000)
}







var Webos   = require('webos-service');
var Request = require('request');
var Service = new Webos("com.lampac.tv.worker");
var Player  = new Api();

Service.activityManager.idleTimeout = 60 * 10; 

function startParse(params, callback){
    var send    = {
        url: params.url,
        method: params.method,
        headers: {}
    }

    var head = JSON.parse(params.headers);

    for(var i in head){
        send.headers[i] = head[i];
    }

    if(params.need_download){
        send.encoding = 'binary';
    }

    if(params.method == 'POST'){
        send.body = params.post;

        send.headers['Content-Type'] = 'application/x-www-form-urlencoded';
    }

    Request(send, function (error, response, body){
        var result = body.length == 0 ? 'error' : body;

        if(params.need_download) result = new Buffer(body.toString(), "binary").toString("base64");

        callback(body.length == 0 ? 'error' : body)
    });
}

 
Service.register("parse", function(message) {
    startParse(message.payload, function(body){
        message.respond({responce: body});
    })
})

Service.register("devices", function(message) {
    Player.search();

    message.respond({devices: Player.devices()});
})

Service.register("play", function(message) {
    Player.send(message.payload.data, message.payload.object, function(result){
        message.respond(result);
    })
})

Service.register("logs", function(message) {
    message.respond({logs: Console.get(), all: Console.all(), tiks: tiks});
})

Service.register("search", function(message) {
    Player.search();

    message.respond({search: true});
})